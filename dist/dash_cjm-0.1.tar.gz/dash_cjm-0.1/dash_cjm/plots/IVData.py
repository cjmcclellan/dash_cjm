import plotly.graph_objs as go


class IVPlotLayout(object):

    pass