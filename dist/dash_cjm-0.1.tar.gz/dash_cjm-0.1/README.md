# dash_cjm

### Uploading Changes
run `python setup.py bdist_wheel`

Then upload to github


### Using dash_cjm with Django

You must install the appropiate apps and middleware.  Look to dash_cjm/test/example.html for an example
of the necessary HTML for creating an app.  You must load the plotly_dash tags, insert 